$('.deleteBtn').click(function(event) {
	$(this).parent().parent().remove();
});