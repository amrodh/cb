$('.property_thumbnail > img').click(function (){
   $('#property_mainimage').attr("src", $(this).attr("src"));
}) ;