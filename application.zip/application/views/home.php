<?php include('header.php') ?>



<div class="container" style="padding: 0px; width: 100%;">
    <?php include('slider.php'); ?>
    <?php include('search_home.php'); ?>

	    <div class="visible-sm visible-xs hidden-lg hidden-md">
	        <?php include('search.php'); ?>
	    </div>

    <?php include('property_alert.php'); ?>
	<?php include('featuredProperties.php'); ?>  
</div>

<?php include('footer.php'); ?>
