    <!-- /#wrapper -->

    <!-- jQuery Version 1.11.0 -->
    <script src="<?php echo base_url(); ?>application/static/js/jquery-1.11.0.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url(); ?>application/static/js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="<?php echo base_url(); ?>application/static/js/plugins/morris/raphael.min.js"></script>
    <script src="<?php echo base_url(); ?>application/static/js/plugins/morris/morris.min.js"></script>
    <script src="<?php echo base_url(); ?>application/static/js/plugins/morris/morris-data.js"></script>
    <script type="text/javascript" src="<?= base_url();?>application/static/js/jquery.bxslider.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>application/static/js/admin.js"></script>

</body>

</html>
