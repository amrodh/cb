<?php include('header.php'); ?>
	<div class="container about_main_div">
		<div class="about_top_div">
            <?php echo $this->lang->line('about_title'); ?>
            <div id="about_breadcrumb">
                <ol class="breadcrumb breadcrumb_styling">
                    <li><a href="http://localhost/ColdwellBanker"><?php echo $this->lang->line('about_breadcrumb1'); ?></a></li>
                    <li class="active"><?php echo $this->lang->line('about_breadcrumb2'); ?></li>
                </ol>
            </div>
        </div>
        <div id="about_bottom_div">

        </div>
	</div>
<?php include('footer.php'); ?>