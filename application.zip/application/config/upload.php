<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
		$config['upload_path'] = getcwd().'/application/static/upload';
		$config['allowed_types'] = 'gif|jpg|png|jpeg';
		// $config['max_size']	= '1000';
		// $config['max_width']  = '1024';
		// $config['max_height']  = '768';
 ?>