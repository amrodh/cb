<?php

$lang['viewallproperties_details'] = "Details";
$lang['viewallproperties_images'] = "Images";
$lang['viewallproperties_share'] = "Share";
$lang['viewallproperties_contact'] = "Contact";
$lang['viewallproperties_button'] = "Compare";