<?php

$lang['uploadcv_title'] = "APPLY HERE";
$lang['uploadcv_input1']	= "First Name";
$lang['uploadcv_input2']	= "Last Name";
$lang['uploadcv_input3']	= "E-mail";
$lang['uploadcv_input4']	= "Upload your CV";
$lang['uploadcv_button']	= "Submit";