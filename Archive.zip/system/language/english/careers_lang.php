<?php

$lang['careers_title1'] = "Uplod Your CV Now!";
$lang['careers_title2']	= "Join Us Now!";
$lang['careers_description1']	= "Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam no nummy nibh euismod tincidunt ut laoreet.";
$lang['careers_description2']	= "Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam no nummy nibh euismod tincidunt ut laoreet.";
$lang['careers_button1']	= "Post Your CV";
$lang['careers_button2']	= "Current Vacancies";