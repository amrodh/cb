<?php

$lang['compare_title'] = "Compare Properties";
$lang['compare_breadcrumb1']	= "Coldwell Banker Home";
$lang['compare_breadcrumb2']	= "Find A Home";
$lang['compare_breadcrumb3']	= "Compare Properties";
$lang['compare_title1']	= "Description";
$lang['compare_title2']	= "Location";
$lang['compare_title3']	= "Highlights";
$lang['compare_title4']	= "Price";
$lang['compare_contact']	= "Contact";
$lang['compare_map']	= "View on Map";