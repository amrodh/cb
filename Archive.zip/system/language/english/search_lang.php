<?php

$lang['search_tab1'] = "HOME";
$lang['search_tab2']	= "RESIDENTIALS";
$lang['search_tab3']	= "COMMERCIALS";
$lang['search_drpdwn1'] = "City";
$lang['search_drpdwn2'] = "District";
$lang['search_drpdwn3'] = "Contract Type";
$lang['search_drpdwn4'] = "Property Type";
$lang['search_drpdwn5'] = "Price Range";
$lang['search_drpdwn6'] = "Area Range";
$lang['search_button'] = "Search";