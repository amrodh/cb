<?php

$lang['propertyalert_title'] = "PROPERTY ALERT";
$lang['propertyalert_subtitle1'] = "City";
$lang['propertyalert_subtitle2'] = "District";
$lang['propertyalert_subtitle3'] = "Contract Type";
$lang['propertyalert_subtitle4'] = "Advanced Filters";
$lang['propertyalert_subtitle5'] = "Price Range";
$lang['propertyalert_subtitle6'] = "Area Range";
$lang['propertyalert_subtitle7'] = "E-mail";
$lang['propertyalert_button'] = "Notify Me";