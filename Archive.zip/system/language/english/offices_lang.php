<?php

$lang['offices_title'] = "OUR OFFICES";
$lang['offices_breadcrumb1']	= "Coldwell Banker Home";
$lang['offices_breadcrumb2']	= "Offices";
$lang['offices_subtitle']	= "Please Choose District";
$lang['offices_title1']	= "District:";
$lang['offices_title2']	= "Address:";
$lang['offices_title3']	= "Open Hours:";
$lang['offices_title4']	= "Phone:";
