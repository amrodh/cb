<?php

$lang['resetpassword_title'] = "تعديل كلمة المرور";
$lang['resetpassword_palceholder1'] = "رجاءً أدخل كلمة السر الجديدة";
$lang['resetpassword_placeholder2'] = "رجاءً أدخل كلمة السر الجديدة";
$lang['resetpassword_button']	= "تعديل";