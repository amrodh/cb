<?php

$lang['propertyalert_title'] = "مخطر العقارات";
$lang['propertyalert_subtitle1'] = "المدينة";
$lang['propertyalert_subtitle2'] = "المنطقة";
$lang['propertyalert_subtitle3'] = "نوع العقد";
$lang['propertyalert_subtitle4'] = "بحث مفصل";
$lang['propertyalert_subtitle5'] = "السعر";
$lang['propertyalert_subtitle6'] = "المساحة";
$lang['propertyalert_subtitle7'] = "البريد الالكتروني";
$lang['propertyalert_button'] = "إرسال";