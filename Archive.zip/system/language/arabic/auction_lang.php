<?php

$lang['auction_title'] = "المزادات";
$lang['auction_breadcrumb1']	= "كولدويل بانكر الرئيسية";
$lang['auction_breadcrumb2']	= "المزادات";
$lang['auction_tab1']	= "الحديث";
$lang['auction_tab2']	= "القادمة";
$lang['auction_calculator_title']	= "الحاسبة المالية";
$lang['auction_calculator_description']	= "حاسبة آلة الدفع الشهري";