<?php

$lang['register_title'] = "التسجيل";
$lang['register_subtitle']	= "أدخل معلوماتك الشخصية للتسجيل";
$lang['register_input1']	= "الاسم الأول";
$lang['register_input2']	= "إسم العائلة";
$lang['register_input3']	= "إسم المستخدم";
$lang['register_input4']	= "البريد الالكتروني";
$lang['register_input5']	= "العنوان";
$lang['register_input6']	= "رقم الهاتف";
$lang['register_input7']	= "كلمة السر";
$lang['register_input8']	= "تأكيد كلمة المرور";
$lang['register_chkbx']	= "إشترك في النشرة الإخبارية";
$lang['register_button']	= "سجل";