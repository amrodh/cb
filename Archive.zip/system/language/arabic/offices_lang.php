<?php

$lang['offices_title'] = "المكاتب";
$lang['offices_breadcrumb1']	= "كولدويل بانكر الرئيسية";
$lang['offices_breadcrumb2']	= "المكاتب";
$lang['offices_subtitle']	= "رجاءً إختر المنطقة";
$lang['offices_title1']	= "المنطقة:";
$lang['offices_title2']	= "";
$lang['offices_title3']	= "";
$lang['offices_title4']	= "";
