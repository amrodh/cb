<?php

$lang['marketindex_title1'] = "نوع الممتلكات";
$lang['marketindex_title2']	= "بناء على";
$lang['marketindex_title3'] = "الممتلكات ل";
$lang['marketindex_title4']	= "نوع العمل";
$lang['marketindex_subtitle1'] = "دنى سعر للمتر المكعب";
$lang['marketindex_subtitle2']	= "أعلى سعر للمتر المكعب";
$lang['marketindex_subtitle3']	= "متوسط السعر للمتر المربع";