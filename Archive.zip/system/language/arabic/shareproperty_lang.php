<?php

$lang['shareproperty_title'] = "إعلن عن الممتلكات الخاصة بك";
$lang['shareproperty_subtitle']	= "معلومات الملكية";
$lang['shareproperty_input1']	= "المساحة";
$lang['shareproperty_input2']	= "النوع";
$lang['shareproperty_input3']	= "السعر";
$lang['shareproperty_input4']	= "المدينة";
$lang['shareproperty_input5']	= "المنطقة";
$lang['shareproperty_input6']	= "العنوان";
$lang['shareproperty_input7']	= "المميزات";
$lang['shareproperty_input8']	= "حمل صور";
$lang['shareproperty_button']	= "قدم";