<?php

$lang['viewallproperties_details'] = "التفاصيل";
$lang['viewallproperties_images'] = "صور";
$lang['viewallproperties_share'] = "شارك";
$lang['viewallproperties_contact'] = "إتصال";
$lang['viewallproperties_button'] = "قارن";