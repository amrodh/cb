<?php

$lang['propertydetails_tab1'] = "التفاصيل";
$lang['propertydetails_tab2']	= "الخريطة";
$lang['propertydetails_title1']	= "الوصف";
$lang['propertydetails_title2']	= "الحاسبة المالية";
$lang['propertydetails_title3']	= "المميزات";
$lang['propertydetails_title4']	= "كيف تريد أن يتم الاتصال بك؟";
$lang['propertydetails_firstname']	= "الاسم الأول";
$lang['propertydetails_lastname']	= "إسم العائلة";
$lang['propertydetails_email']	= "البريد الالكتروني";
$lang['propertydetails_phone']	= "رقم الهاتف";
$lang['propertydetails_interest']	= "أنا مهتم في:";
$lang['propertydetails_chkbx1']	= "شراء";
$lang['propertydetails_chkbx2']	= "بيع";
$lang['propertydetails_chkbx3']	= "إيجار";
$lang['propertydetails_text']	= "يرجى إستخدم مربع النص أدناه لتقديم أي تعليقات أو اسئلة";
$lang['propertydetails_button']	= "إرسال";

$lang['propertydetails_calculator_title1']	= "الدفعة الشهرية";
$lang['propertydetails_calculator_subtitle1']	= "Understanding your monthly costs can help you plan ahead and make important housing decisions.";
$lang['propertydetails_calculator_title2']	= "ألة حساب الدفع الشهري";
$lang['propertydetails_calculator_subtitle2']	= "أدخل قرضك و معلومات الممتلكات الخاصة بك.";
$lang['propertydetails_calculator_title3']	= "معلومات الشراء";
$lang['propertydetails_calculator_title4']	= "سعر الشراء:";
$lang['propertydetails_calculator_title5']	= "الدفعة الأولى:";
$lang['propertydetails_calculator_title6']	= "الفائدة:";
$lang['propertydetails_calculator_title7']	= "نتائجك";
$lang['propertydetails_calculator_title8']	= "الرصيد المتبقي:";
$lang['propertydetails_calculator_title9']	= "مجموع الدفعات:";
$lang['propertydetails_calculator_title10']	= "الدفع الشهري:";
$lang['propertydetails_calculator_title11']	= "مدة القرض:";
$lang['propertydetails_calculator_button']	= "حساب";