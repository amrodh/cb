<?php

$lang['searchhome_title'] = "العثور على منزل";
$lang['searchhome_advanced']	= "بحث بالتفصيل";
$lang['searchhome_button']	= "بحث";