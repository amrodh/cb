<?php generateMap($officeInfo->latitude,$officeInfo->longitude,'100%','300px'); ?>
<?php //printme($officeInfo->latitude);?>