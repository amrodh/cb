<?php

$lang['careers_title1'] = "ارسل سيرتك الذاتية!";
$lang['careers_title2']	= "إنضم إلينا الأن!";
$lang['careers_description1']	= "Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam no nummy nibh euismod tincidunt ut laoreet.";
$lang['careers_description2']	= "Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam no nummy nibh euismod tincidunt ut laoreet.";
$lang['careers_button1']	= "حمل سيرتك الذاتية";
$lang['careers_button2']	= "الوظائف الشاغرة";