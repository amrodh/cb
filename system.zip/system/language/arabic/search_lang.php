<?php

$lang['search_tab1'] = "الرئيسية";
$lang['search_tab2']	= "سكني";
$lang['search_tab3']	= "تجارية";
$lang['search_drpdwn1'] = "المدينة";
$lang['search_drpdwn2'] = "المنطقة";
$lang['search_drpdwn3'] = "نوع العقد";
$lang['search_drpdwn4'] = "نوع الملكية";
$lang['search_drpdwn5'] = "السعر";
$lang['search_drpdwn6'] = "المساحة";
$lang['search_button'] = "بحث";