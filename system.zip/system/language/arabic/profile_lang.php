<?php

$lang['profile_title'] = "الملف الشخصي";
$lang['profile_name'] = "إسم المستخدم:";
$lang['profile_email'] = "البريد الالكتروني:";
$lang['profile_location'] = "العنوان:";
$lang['profile_phone'] = "رقم الهاتف:";
$lang['profile_button'] = "تعديل البيانات";
$lang['profile_title2']	= "العقارات المفضلة";

