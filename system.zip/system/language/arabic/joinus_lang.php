<?php

$lang['joinus_title'] = "الوظائف الشاغرة";
$lang['joinus_button']	= "قدم الأن";