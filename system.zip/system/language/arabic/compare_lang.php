<?php

$lang['compare_title'] = "مقارنة الممتلكات";
$lang['compare_breadcrumb1']	= "كولدويل بانكر الرئيسية";
$lang['compare_breadcrumb2']	= "العثور على منزل";
$lang['compare_breadcrumb3']	= "مقارنة الممتلكات";
$lang['compare_title1']	= "الوصف";
$lang['compare_title2']	= "الموقع";
$lang['compare_title3']	= "المميزات";
$lang['compare_title4']	= "السعر";
$lang['compare_contact']	= "إتصل";
$lang['compare_map']	= "العرض على الخريطة";