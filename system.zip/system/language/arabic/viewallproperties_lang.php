<?php

$lang['viewallproperties_details'] = "التفاصيل";
$lang['viewallproperties_images'] = "صور";
$lang['viewallproperties_share'] = "شارك";
$lang['viewallproperties_contact'] = "إتصال";
$lang['viewallproperties_button'] = "قارن";
$lang['viewallproperties_placeholder1'] = "رجاءً أدخل الاسم الأول";
$lang['viewallproperties_placeholder2'] = "رجاءً أدخل إسم العائلة";
$lang['viewallproperties_placeholder3'] = "رجاءً أدخل البريد الالكتروني";
$lang['viewallproperties_placeholder4'] = "رجاءً أدخل رقم الهاتف";