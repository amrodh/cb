<?php

$lang['forgotpassword_title'] = "نسيت كلمة المرور";
$lang['forgotpassword_subtitle']	= "رجاءً أدخل بريدك الالكتروني ليتم تغيير كلمة المرور";
$lang['forgotpassword_placeholder']	= "رجاءً أدخل بريدك الالكتروني";
$lang['forgotpassword_button']	= "إرسال";