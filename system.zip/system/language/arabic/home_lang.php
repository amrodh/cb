<?php 

$lang['home_login'] = "دخول";
$lang['home_register'] = "تسجيل";
$lang['home_menu1'] = "العثور على منزل";
$lang['home_menu2'] = "التجارية";
$lang['home_menu3'] = "المزادات التجارية";
$lang['home_menu4'] = "مركز التدريب";
$lang['home_menu5'] = "الخدمات ";
$lang['home_menu6'] = "من نحن";
$lang['home_menu7'] = "إتصل بنا";
$lang['home_submenu1'] = "مجمع سكني";
$lang['home_submenu2'] = "عقارات مملوكة من قبل";
$lang['home_submenu3'] = "عقارات للتأجير";
$lang['home_submenu4'] = "شراء";
$lang['home_submenu5'] = "تأجير";
$lang['home_submenu6'] = "مؤشر السوق";
$lang['home_submenu7'] = "إعلن عن الممتلكات الخاصة بك";
$lang['home_submenu8'] = "المكاتب";
$lang['home_submenu9'] = "الوظائف";
$lang['home_login_text'] = "أدخل الاسم وكلمة السر للدخول";
$lang['home_login_input1'] = "الإسم:";
$lang['home_login_input2'] = "كلمة السر:";
$lang['home_login_placeholder1'] = "رجاءً أدخل الإسم";
$lang['home_login_placeholder2'] = "رجاءً أدخل كلمة السر";
$lang['home_login_forgotpassword'] = "نسيت كلمة المرور";


$lang['home_footer_submenu1'] = "مجمع سكني";
$lang['home_footer_submenu2'] = "عقارات مملوكة من قبل";
$lang['home_footer_submenu3'] = "عقارات للتأجير";
$lang['home_footer_submenu4'] = "شراء";
$lang['home_footer_submenu5'] = "تأجير";
$lang['home_footer_submenu6'] = "مؤشر السوق";
$lang['home_footer_submenu7'] = "إعلن عن الممتلكات الخاصة بك";
$lang['home_footer_submenu8'] = "المكاتب";
$lang['home_footer_submenu9'] = "الوظائف";
$lang['home_footer_submenu10'] = "تاريخ كولدويل بانكر";
$lang['home_footer_submenu11'] = "مركز الاتصال";
// $lang['home_footer_drpdwn1'] = "Villas";
// $lang['home_footer_drpdwn2'] = "Apartment";
// $lang['home_footer_drpdwn3'] = "Building";

?>