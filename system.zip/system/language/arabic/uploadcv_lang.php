<?php

$lang['uploadcv_title'] = "قدم هنا";
$lang['uploadcv_input1']	= "الاسم الاول";
$lang['uploadcv_input2']	= "إسم العائلة";
$lang['uploadcv_input3']	= "البريد الالكتروني";
$lang['uploadcv_input4']	= "البريد الالكتروني";
$lang['uploadcv_button']	= "قدم";