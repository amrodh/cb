<?php

$lang['featured_title'] = "المشاريع المميزة";
// $lang['featured_button']	= "قدم الأن";