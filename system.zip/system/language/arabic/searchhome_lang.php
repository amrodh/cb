<?php

$lang['searchhome_title'] = "العثور على عقار";
$lang['searchhome_advanced']	= "بحث بالتفصيل";
$lang['searchhome_button']	= "بحث";