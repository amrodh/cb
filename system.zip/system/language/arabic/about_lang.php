<?php

$lang['about_title'] = "من نحن";
$lang['about_breadcrumb1']	= "كولدويل بانكر الرئيسية";
$lang['about_breadcrumb2']	= "من نحن";