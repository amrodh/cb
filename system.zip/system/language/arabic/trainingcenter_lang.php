<?php

$lang['trainingcenter_title'] = "مركز التدريب";
$lang['trainingcenter_breadcrumb1']	= "كولدويل بانكر الرئيسية ";
$lang['trainingcenter_breadcrumb2']	= "مركز التدريب";
$lang['trainingcenter_tab1']	= "الصف الاول";
$lang['trainingcenter_tab2']	= "الصف الثاني";
$lang['trainingcenter_tab3']	= "الصف الثالث";