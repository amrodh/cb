<?php

$lang['offices_title'] = "المكاتب";
$lang['offices_breadcrumb1']	= "كولدويل بانكر الرئيسية";
$lang['offices_breadcrumb2']	= "المكاتب";
$lang['offices_subtitle']	= "رجاءً إختر المنطقة";
$lang['offices_title1']	= "المنطقة:";
$lang['offices_title2']	= "العنوان:";
$lang['offices_title3']	= "ساعات العمل:";
$lang['offices_title4']	= "رقم الهاتف:";

$lang['offices_input1']	= "الاسم الاول:";
$lang['offices_input2']	= "إسم العائلة:";
$lang['offices_input3']	= "البريد الالكتروني:";
$lang['offices_input4']	= "رقم الهاتف:";
$lang['offices_input5']	= "الرسالة:";

$lang['offices_contact_success']	= "تم إدخال معلوماتك بنجاح!";
$lang['offices_contact_error']	= "لم تدخل معلوماتك بنجاح. رجاءً عاود المحاولة في واقتاً لاحقاً.";