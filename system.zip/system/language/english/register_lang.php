<?php

$lang['register_title'] = "REGISTRATION FORM";
$lang['register_subtitle']	= "Enter your personal information to register.";
$lang['register_input1']	= "First Name";
$lang['register_input2']	= "Last Name";
$lang['register_input3']	= "Username";
$lang['register_input4']	= "E-mail";
$lang['register_input5']	= "Location";
$lang['register_input6']	= "Phone";
$lang['register_input7']	= "Password";
$lang['register_input8']	= "Confirm Password";
$lang['register_input9']	= "Birth Date";
$lang['register_chkbx']	= "Subscribe for Newsletter";
$lang['register_button']	= "Submit";