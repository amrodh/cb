<?php

$lang['searchhome_title'] = "FIND A PROPERTY";
$lang['searchhome_advanced']	= "Advanced Search";
$lang['searchhome_button']	= "Search";