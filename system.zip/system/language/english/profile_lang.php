<?php

$lang['profile_title'] = "PERSONAL PROFILE";
$lang['profile_name'] = "Username:";
$lang['profile_email'] = "E-mail:";
$lang['profile_location'] = "Location:";
$lang['profile_phone'] = "Phone:";
$lang['profile_button'] = "Edit";
$lang['profile_title2']	= "Favorite Properties";