<?php

$lang['viewallproperties_details'] = "Details";
$lang['viewallproperties_images'] = "Images";
$lang['viewallproperties_share'] = "Share";
$lang['viewallproperties_contact'] = "Contact";
$lang['viewallproperties_button'] = "Compare";
$lang['viewallproperties_placeholder1'] = "Please enter first name";
$lang['viewallproperties_placeholder2'] = "Please enter last name";
$lang['viewallproperties_placeholder3'] = "Please enter email";
$lang['viewallproperties_placeholder4'] = "Please enter phone number";