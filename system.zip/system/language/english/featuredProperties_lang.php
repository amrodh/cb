<?php

$lang['featured_title'] = "FEATURED PROPERTIES";
// $lang['featured_button']	= "قدم الأن";