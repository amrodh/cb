<?php

$lang['joinus_title'] = "CURRENT VACANCIES";
$lang['joinus_button']	= "Apply Now";