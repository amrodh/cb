<?php

$lang['about_title'] = "ABOUT US";
$lang['about_breadcrumb1']	= "Coldwell Banker Home";
$lang['about_breadcrumb2']	= "About Us";