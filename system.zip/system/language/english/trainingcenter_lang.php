<?php

$lang['trainingcenter_title'] = "TRAINING CENTER";
$lang['trainingcenter_breadcrumb1']	= "Coldwell Banker Home";
$lang['trainingcenter_breadcrumb2']	= "Training Center";
$lang['trainingcenter_tab1']	= "Course 1";
$lang['trainingcenter_tab2']	= "Course 2";
$lang['trainingcenter_tab3']	= "Course 3";