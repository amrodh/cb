<?php

$lang['forgotpassword_title'] = "FORGOT PASSWORD";
$lang['forgotpassword_subtitle']	= "Enter your email to reset password";
$lang['forgotpassword_placeholder']	= "Please Enter your E-mail";
$lang['forgotpassword_button']	= "Submit";