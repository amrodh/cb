<?php

$lang['auction_title'] = "AUCTION";
$lang['auction_breadcrumb1']	= "Coldwell Banker Home";
$lang['auction_breadcrumb2']	= "Auctions";
$lang['auction_tab1']	= "Recent";
$lang['auction_tab2']	= "Upcoming";
$lang['auction_calculator_title']	= "Top Tool";
$lang['auction_calculator_description']	= "Monthly Payment Calculator";