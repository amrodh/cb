<?php

$lang['marketindex_title1'] = "Property Type";
$lang['marketindex_title2']	= "Based On";
$lang['marketindex_title3'] = "Property For";
$lang['marketindex_title4']	= "Business Type";
$lang['marketindex_subtitle1'] = "Lowest Price per m2";
$lang['marketindex_subtitle2']	= "Highest Price per m2";
$lang['marketindex_subtitle3']	= "Average Price per m2";