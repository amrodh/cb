<?php

$lang['shareproperty_title'] = "SHARE YOUR PROPERTY";
$lang['shareproperty_subtitle']	= "Property Information";
$lang['shareproperty_input1']	= "Area";
$lang['shareproperty_input2']	= "Type";
$lang['shareproperty_input3']	= "Price";
$lang['shareproperty_input4']	= "City";
$lang['shareproperty_input5']	= "District";
$lang['shareproperty_input6']	= "Address";
$lang['shareproperty_input7']	= "Features";
$lang['shareproperty_input8']	= "Upload Images";
$lang['shareproperty_input9']	= "Category";
$lang['shareproperty_button']	= "Submit";