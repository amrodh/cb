<?php

$lang['resetpassword_title'] = "RESET PASSWORD";
$lang['resetpassword_palceholder1'] = "Please enter your password";
$lang['resetpassword_placeholder2'] = "Please re-enter your password";
// $lang['resetpassword_button']	= "Apply Now";